// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.event.events;

import me.earth.phobos.event.EventStage;

public class UpdateWalkingPlayerEvent extends EventStage
{
    public UpdateWalkingPlayerEvent(final int stage) {
        super(stage);
    }
}
